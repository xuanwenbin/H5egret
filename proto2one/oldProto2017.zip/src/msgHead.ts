    import fs = require('fs');

    console.log("开始生成msghead");
    let commonjson = require("../common.json");
    let enums:any[] = commonjson["enums"];
    let outContent = [];
    for(let i=0;i<enums.length;i++){
        if(enums[i].name=="MsgHead"){
            let classNames:any[] = enums[i].values;

            classNames.forEach(value=>{
                outContent.push('           public static z'+value.id+':string  = "'+value.name+'"; ');
            });

            classNames.forEach(value=>{
                outContent.push('           public static '+value.name+':{id:number,name:string,clz:protoTS.'+value.name+'}  = {id:'+value.id+',name:"'+value.name+'",clz:null}; ');
            });

        }
    }

    let msghead = `
    class MsgHead{
        `+outContent.join("\n")+`   
    }`;

    fs.writeFileSync("MsgHead.ts", msghead);
