import child_process = require('child_process');
import fs = require("fs");
import * as one from './proto2one';

let msgtsPath = "../main/libs/msg.d.ts";
let protobufPath = "../main/resource/cfg/common.proto";
let msgHeadPath = "../main/src/extended/MsgHead.ts";

let proto2one = new one.Proto2one();
proto2one.load(()=>{
    console.log("protobu f文件合并完成");
    let buff = child_process.execSync('node node_modules/protobufjs/bin/pbjs common.proto -t json > common.json');
    console.log(buff.toString());
    buff = child_process.execSync('node out/command.js --file common.json > msg.d.ts');
    console.log(buff.toString());
    buff = child_process.execSync('node out/MsgHead.js');
    console.log(buff.toString());
    fs.writeFileSync(msgtsPath, fs.readFileSync('msg.d.ts'));
    fs.writeFileSync(protobufPath, fs.readFileSync('common.proto'));
    fs.writeFileSync(msgHeadPath, fs.readFileSync('MsgHead.ts'));
    console.log("编译完成"); 
});